/* 
 * mm.c -  Simple allocator based on implicit free lists, 
 *                  first fit placement, and boundary tag coalescing. 
 *
 * Each block has header of the form:
 * 
 *      31                     3  2  1  0 
 *      -----------------------------------
 *     | s  s  s  s  ... s  s  s  0  0  a/f
 *      ----------------------------------- 
 * 
 * where s are the meaningful size bits and a/f is set 
 * iff the block is allocated. The list has the following form:
 *
 * heap                             heap
 * start                            end  
 *  ---------------------------------
 * |  pad   | zero or more usr blks |
 *  ---------------------------------
 *          |                       |
 *          |                       |
 *
 */
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stddef.h>
#include "mm.h"
#include "memlib.h"

/* Team structure */
team_t team = {
    "implicit first fit", 
    "Dave OHallaron", "droh",
    "", ""
}; 

typedef struct block {
    size_t header;
    unsigned char payload[];
} block_t;

/* $begin mallocmacros */
/* Basic constants and macros */
#define WSIZE       4       /* word size (bytes) */  
#define DSIZE       8       /* doubleword size (bytes) */
#define OVERHEAD    8       /* overhead of header and footer (bytes) */

/* Pack a size and allocated bit into a word */
#define PACK(size, alloc)  ((size) | (alloc))

/* Read and write a word at address p */
#define GET(p)       (*(size_t *)(p))
#define PUT(p, val)  (*(size_t *)(p) = (val))  

/* Read the size and allocated fields from address p */
#define GET_SIZE(p)  (GET(p) & ~0x7)
#define GET_ALLOC(p) (GET(p) & 0x1)

/* Given block ptr bp, compute address of its header and footer */
#define HDRP(p)  (block_t *) ((unsigned char *) p - offsetof(block_t, payload))

/* Given block ptr bp, compute address of next and previous blocks */
#define NEXT_BLKP(block)  (block_t *) ((unsigned char *) block+ GET_SIZE(block))
/* $end mallocmacros */

/* Global variables */
static block_t *heap_start; 
static block_t *heap_end; 

/* function prototypes for internal helper routines */
static block_t *extend_heap(size_t words);
static void place(block_t *bp, size_t asize);
static block_t *find_fit(size_t asize);
static void coalesce(block_t *bp);

/* 
 * mm_init - Initialize the memory manager 
 */
int mm_init(void) 
{
    /* create the initial empty heap */
    char *bp = (char *) heap_start;
    if ((bp = mem_sbrk(WSIZE)) == NULL)
	return -1;
    PUT(bp, 0);                        /* alignment padding */
    bp += WSIZE;
    heap_start = (block_t *) bp;
    heap_end = heap_start;
    return 0;
}

/* 
 * mm_malloc - Allocate a block with at least size bytes of payload 
 */
void *mm_malloc(size_t size) 
{
    size_t asize;      /* adjusted block size */
    block_t *bp;      

    /* Adjust block size to include overhead and alignment reqs. */
    if (size <= DSIZE)
        asize = DSIZE + OVERHEAD;
    else
        asize = DSIZE + ((size + 7) / OVERHEAD) * OVERHEAD;
    
    /* TODO: Search the free list for a fit */
    /* TODO: No fit found. Get more memory and place the block */
} 

/* 
 * mm_free - Free a block 
 */
void mm_free(void *bp)
{
    /* TODO */
}

/*
 * mm_realloc - naive implementation of mm_realloc
 */
void *mm_realloc(void *ptr, size_t size)
{
    void *newp;
    size_t copySize;

    if ((newp = mm_malloc(size)) == NULL) {
	printf("ERROR: mm_malloc failed in mm_realloc\n");
	exit(1);
    }
    copySize = GET_SIZE(HDRP(ptr));
    if (size < copySize)
      copySize = size;
    memcpy(newp, ptr, copySize);
    mm_free(ptr);
    return newp;
}

/* The remaining routines are internal helper routines */

/* 
 * extend_heap - Extend heap with free block and return its block pointer
 */
static block_t *extend_heap(size_t words) 
{
    block_t *bp;
    size_t size;
	
    /* TODO: Allocate an even number of words to maintain alignment */
}

/* 
 * place - Place block of asize bytes at start of free block bp 
 *         and split if remainder would be at least minimum block size (16 bytes)
 */
static void place(block_t *bp, size_t asize)
{
    /* TODO */
}

/* 
 * find_fit - Find a fit for a block with asize bytes 
 */
static block_t *find_fit(size_t asize)
{
    /* TODO: first fit search */
}

/*
 * coalesce 
 */
static void coalesce(block_t *bp) 
{
    /* TODO */
}
